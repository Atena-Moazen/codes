﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c_m
{
    public partial class def_merch : Form
    {
        public def_merch()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = this.textBox1.Text;
            string code = this.textBox2.Text;
            string price = this.textBox3.Text;

            File.AppendAllText("./merch.csv", name + "," + code + "," + price + "\n");
            MessageBox.Show("Successfully added");
        }
    }
}
