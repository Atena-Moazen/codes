namespace c_m
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            def_customer cs = new def_customer();
            cs.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            def_merch kala = new def_merch();
            kala.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            customers_list cmlist = new customers_list();
            cmlist.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            merch_list klist = new merch_list();
            klist.Show();
        }
    }
}